<html>
<head><title>Loading</title></head>
<body>
<script language="javascript">window.location.href='{!! $url !!}'</script>
<noscript><meta http-equiv="refresh" content="0;url={!! $url !!}"></noscript>
</body>
</html>
<!-- a padding to disable MSIE and Chrome friendly error page -->
<!-- a padding to disable MSIE and Chrome friendly error page -->
<!-- a padding to disable MSIE and Chrome friendly error page -->
<!-- a padding to disable MSIE and Chrome friendly error page -->
<!-- a padding to disable MSIE and Chrome friendly error page -->
<!-- a padding to disable MSIE and Chrome friendly error page -->
