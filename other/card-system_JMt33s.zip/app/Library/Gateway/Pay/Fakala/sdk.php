<?php
class fakala { public $gateway; public $uid; public $key; public function __construct($spe1409a, $spbf68a1, $sp10da54) { $this->gateway = $spe1409a; $this->uid = $spbf68a1; $this->key = $sp10da54; } function getSignStr($sp413bca) { ksort($sp413bca); $sp4a6360 = ''; foreach ($sp413bca as $spaeed3c => $spa45e51) { if ('sign' !== $spaeed3c) { $sp4a6360 .= $spaeed3c . '=' . $spa45e51 . '&'; } } return $sp4a6360; } function getSign($sp413bca, $sp10da54, &$spcca016 = false) { $sp4a6360 = self::getSignStr($sp413bca); $sp10cd1f = md5($sp4a6360 . 'key=' . $sp10da54); if ($spcca016 !== false) { $spcca016 = $sp4a6360 . 'sign=' . $sp10cd1f; } return $sp10cd1f; } function goPay($sp94a44d, $sp73abe8, $spce6180, $sp1f80b5, $sp32f18a, $spe7f323, $sp26c908, $sp2b3607) { $sp413bca = array('version' => '20190501', 'uid' => (int) $this->uid, 'subject' => $sp73abe8, 'out_trade_no' => $spce6180, 'total_fee' => (int) $sp32f18a, 'cost' => (int) $sp1f80b5, 'payway' => $sp94a44d, 'return_url' => $sp26c908, 'notify_url' => $sp2b3607, 'attach' => $spe7f323); $sp413bca['sign'] = $this->getSign($sp413bca, $this->key); die('
<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>正在转到付款页</title>
</head>
<body onload="document.pay.submit()">
<form name="pay" action="' . $this->gateway . '/api/order" method="post">
    <input type="hidden" name="version" value="' . $sp413bca['version'] . '">
    <input type="hidden" name="uid" value="' . $sp413bca['uid'] . '">
    <input type="hidden" name="subject" value="' . $sp413bca['subject'] . '">
    <input type="hidden" name="out_trade_no" value="' . $sp413bca['out_trade_no'] . '">
    <input type="hidden" name="total_fee" value="' . $sp413bca['total_fee'] . '">
    <input type="hidden" name="cost" value="' . $sp413bca['cost'] . '">
    <input type="hidden" name="payway" value="' . $sp413bca['payway'] . '">
    <input type="hidden" name="return_url" value="' . $sp413bca['return_url'] . '">
    <input type="hidden" name="notify_url" value="' . $sp413bca['notify_url'] . '">
    <input type="hidden" name="attach" value="' . $sp413bca['attach'] . '">
    <input type="hidden" name="sign" value="' . $sp413bca['sign'] . '">
</form>
</body>
        '); } function notify_verify() { $sp413bca = $_POST; if ($sp413bca['sign'] === $this->getSign($sp413bca, $this->key)) { echo 'success'; return true; } else { echo 'fail'; return false; } } function return_verify() { $sp413bca = $_GET; if ($sp413bca['sign'] === $this->getSign($sp413bca, $this->key)) { return true; } else { return false; } } function get_order($spce6180) { $sp5c45d8 = $this->curl_post($this->gateway . '/api/order/query', 'uid=' . $this->uid . '&out_trade_no=' . $spce6180); $sp5c45d8 = @json_decode($sp5c45d8, true); if (is_array($sp5c45d8) && is_array($sp5c45d8['data']) && isset($sp5c45d8['data']['order'])) { return $sp5c45d8['data']['order']; } return array(); } private function curl_post($sp09d604, $sp931fd0) { $spdc136d = curl_init($sp09d604); curl_setopt($spdc136d, CURLOPT_HEADER, 0); curl_setopt($spdc136d, CURLOPT_RETURNTRANSFER, 1); curl_setopt($spdc136d, CURLOPT_SSL_VERIFYPEER, true); curl_setopt($spdc136d, CURLOPT_POST, true); curl_setopt($spdc136d, CURLOPT_POSTFIELDS, $sp931fd0); $sp7fa26f = curl_exec($spdc136d); curl_close($spdc136d); return $sp7fa26f; } }