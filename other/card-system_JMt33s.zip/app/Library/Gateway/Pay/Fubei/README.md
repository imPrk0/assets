准备工作 http://docs.51fubei.com/open-api/product/preparatoryWork.html

后台添加支付方式

支付方式填wechat或alipay

驱动填 Fubei

配置json格式
```
{
  "app_id": "你的appid",
  "secret": "你的secret",
  "store_id": "你的店铺id"
}
```

示例
![ali.jpg](https://i.loli.net/2019/07/21/5d34731d6ce6d30921.jpg)
![wechat.jpg](https://i.loli.net/2019/07/21/5d34731d8849133862.jpg)
