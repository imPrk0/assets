# Card-Gateways

The Gateways of [card-system](https://github.com/Tai7sy/card-system)

Support Alipay, WechatPay, JCBPay, Paypal, [MugglePay](https://github.com/Tai7sy/card-gateway/tree/master/Pay/MugglePay), etc.
