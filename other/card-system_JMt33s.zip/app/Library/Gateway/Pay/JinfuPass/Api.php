<?php
namespace Gateway\Pay\JinfuPass; use App\Library\CurlRequest; use App\Library\Helper; use Gateway\Pay\ApiInterface; use Illuminate\Support\Facades\Log; class Api implements ApiInterface { private $url_notify = ''; private $url_return = ''; public function __construct($spbf68a1) { $this->url_notify = SYS_URL_API . '/pay/notify/' . $spbf68a1; $this->url_return = SYS_URL . '/pay/return/' . $spbf68a1; } function goPay($sp3125db, $spce6180, $sp73abe8, $spe456af, $spb7b113) { if (!isset($sp3125db['mch_id'])) { throw new \Exception('请填写商户号 mch_id'); } if (!isset($sp3125db['key'])) { throw new \Exception('请填写key'); } $sp94a44d = $sp3125db['payway']; $this->url_return .= '/' . $spce6180; switch ($sp94a44d) { case 'wx': $sp690165 = '102'; return $this->api_scan($sp3125db, $sp690165, 'wechat', $spce6180, $sp73abe8, $spe456af, $spb7b113); break; case 'qq': $sp690165 = '103'; return $this->api_scan($sp3125db, $sp690165, 'qq', $spce6180, $sp73abe8, $spe456af, $spb7b113); break; case 'alipay': $sp690165 = '101'; return $this->api_scan($sp3125db, $sp690165, 'aliqr', $spce6180, $sp73abe8, $spe456af, $spb7b113); break; case 'unionpay': $sp690165 = '104'; return $this->api_scan($sp3125db, $sp690165, 'unionpay', $spce6180, $sp73abe8, $spe456af, $spb7b113); break; case 'jd': $sp690165 = '105'; return $this->api_scan($sp3125db, $sp690165, 'jd', $spce6180, $sp73abe8, $spe456af, $spb7b113); break; case 'wxwap': if (strpos(@$_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false) { $sp690165 = '3030'; return $this->api_pay_in_app($sp3125db, $sp690165, $spce6180, $sp73abe8, $spe456af, $spb7b113); } else { $sp690165 = '206'; return $this->api_wap($sp3125db, $sp690165, $spce6180, $sp73abe8, $spe456af, $spb7b113); } break; case 'qqwap': if (strpos(@$_SERVER['HTTP_USER_AGENT'], 'MQQBrowser') !== false) { $sp690165 = '304'; return $this->api_pay_in_app($sp3125db, $sp690165, $spce6180, $sp73abe8, $spe456af, $spb7b113); } else { $sp690165 = '203'; return $this->api_h5($sp3125db, $sp690165, $spce6180, $sp73abe8, $spe456af, $spb7b113); } break; case 'alipaywap': if (strpos(@$_SERVER['HTTP_USER_AGENT'], 'AlipayClient') !== false) { $sp690165 = '302'; return $this->api_pay_in_app($sp3125db, $sp690165, $spce6180, $sp73abe8, $spe456af, $spb7b113); } else { $sp690165 = '205'; return $this->api_h5($sp3125db, $sp690165, $spce6180, $sp73abe8, $spe456af, $spb7b113); } break; default: throw new \Exception('支付渠道错误'); } } function verify($sp3125db, $sp5aca2e) { $spd8c93f = isset($sp3125db['isNotify']) && $sp3125db['isNotify']; if ($spd8c93f) { $sp30b796 = $sp3125db['mch_id']; $spcf3725 = $sp3125db['key']; $spce6180 = $_POST['out_trade_no']; $spc73885 = $_POST['trade_state']; $sp996e75 = 'CNY'; $spa63646 = $_POST['pay_type']; $spf507a6 = (int) $_POST['total_amount']; $sp2a0c59 = $_POST['receipt_amount']; $spb9f80f = $_POST['sys_trade_no']; $sp789653 = $_POST['txn_id']; $sp4eb71f = $_POST['device_info']; $spe7f323 = $_POST['attach']; $sp6eff98 = $_POST['time_end']; $sp10cd1f = $_POST['sign']; $sp0fb41b = sprintf('mch_id=%s&fee_type=%s&pay_type=%s&total_amount=%s&device_info=%s&coupon_amount=%s&key=%s', $sp30b796, $spce6180, $sp996e75, $spa63646, $spf507a6, $sp4eb71f, $spcf3725); if ($sp10cd1f == md5($sp0fb41b)) { $sp5aca2e($spce6180, $spf507a6, $spb9f80f); echo 'success'; return true; } else { echo 'FAIL'; return false; } } else { $spce6180 = @$sp3125db['out_trade_no']; if (strlen($spce6180) < 5) { throw new \Exception('交易单号未传入'); } $sp10cd1f = md5('version=1.0&mch_id=' . $sp3125db['mch_id'] . '&out_trade_no=' . $spce6180 . '&sys_trade_no=&key=' . $sp3125db['key']); $sp79334f = array('version' => '1.0', 'mch_id' => $sp3125db['mch_id'], 'out_trade_no' => $spce6180, 'sys_trade_no' => '', 'sign' => $sp10cd1f); $spfc27c0 = CurlRequest::post('https://pay.jinfupass.com/gateway/query', http_build_query($sp79334f)); $spa51230 = @json_decode($spfc27c0, true); if (!$spa51230 || !isset($spa51230['result_code']) || $spa51230['result_code'] !== '1') { Log::error('Pay.JinfuPass.verify.order Error#1: ' . $spfc27c0); throw new \Exception('获取付款信息超时, 请刷新重试'); } if ($spa51230['trade_state'] === '1') { $sp5aca2e($spa51230['out_trade_no'], (int) $spa51230['total_amount'], $spa51230['sys_trade_no']); return true; } return false; } } private function api_scan($sp3125db, $sp690165, $sped6ca8, $spce6180, $sp73abe8, $spe456af, $spb7b113) { $sp30b796 = $sp3125db['mch_id']; $sp10da54 = $sp3125db['key']; $sp2b3607 = $this->url_notify; $sp0fb41b = sprintf("version=1.0&mch_id={$sp30b796}&pay_type={$sp690165}&total_amount={$spb7b113}&out_trade_no={$spce6180}&notify_url={$sp2b3607}&key={$sp10da54}"); $sp10cd1f = md5($sp0fb41b); $sp931fd0 = array('version' => '1.0', 'mch_id' => $sp30b796, 'pay_type' => $sp690165, 'fee_type' => 'CNY', 'total_amount' => $spb7b113, 'out_trade_no' => $spce6180, 'device_info' => date('YmdHis'), 'notify_url' => $sp2b3607, 'body' => $sp73abe8, 'attach' => '', 'time_start' => '', 'time_expire' => '', 'limit_credit_pay' => '0', 'hb_fq_num' => '', 'hb_fq_percent' => '', 'sign' => $sp10cd1f); $sp79334f = $sp931fd0; $spfc27c0 = CurlRequest::post('http://pay.jinfupass.com/gateway/pay', http_build_query($sp79334f)); $spa51230 = @json_decode($spfc27c0, true); if (!$spa51230 || !isset($spa51230['result_code']) || $spa51230['result_code'] !== '1') { Log::error('Pay.JinfuPass.api_scan Error#1: ' . $spfc27c0); throw new \Exception('获取付款信息超时, 请刷新重试'); } if (empty($spa51230['code_url'])) { Log::error('Pay.JinfuPass.api_scan Error#2: ' . $spfc27c0); throw new \Exception('获取付款信息失败, 请联系客服反馈'); } header('location: /qrcode/pay/' . $spce6180 . '/' . strtolower($sped6ca8) . '?url=' . urlencode($spa51230['code_url'])); die; } private function api_pay_in_app($sp3125db, $sp690165, $spce6180, $sp73abe8, $spe456af, $spb7b113) { $sp30b796 = $sp3125db['mch_id']; $sp10da54 = $sp3125db['key']; $sp2b3607 = $this->url_notify; $sp0fb41b = sprintf("version=1.0&mch_id={$sp30b796}&pay_type={$sp690165}&total_amount={$spb7b113}&out_trade_no={$spce6180}&notify_url={$sp2b3607}&key={$sp10da54}"); $sp10cd1f = md5($sp0fb41b); die('
<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>正在转到付款页</title>
</head>
<body onload="document.pay.submit()">
<form name="pay" action="https://pay.jinfupass.com/gateway/jspay2" method="post">
    <input type="hidden" name="version" value="1.0">
    <input type="hidden" name="mch_id" value="' . $sp30b796 . '">
    <input type="hidden" name="pay_type" value="' . $sp690165 . '">
    <input type="hidden" name="minipg" value="0">
    <input type="hidden" name="fee_type" value="CNY">
    <input type="hidden" name="total_amount" value="' . $spb7b113 . '">
    <input type="hidden" name="out_trade_no" value="' . $spce6180 . '">
    <input type="hidden" name="notify_url" value="' . $this->url_notify . '">
    <input type="hidden" name="return_url" value="' . $this->url_return . '">
    <input type="hidden" name="body" value="' . $sp73abe8 . '">
    <input type="hidden" name="sp_client_ip" value="' . Helper::getIP() . '">
    <input type="hidden" name="sign" value="' . $sp10cd1f . '">
</form>
</body>
        '); } private function api_h5($sp3125db, $sp690165, $spce6180, $sp73abe8, $spe456af, $spb7b113) { $sp30b796 = $sp3125db['mch_id']; $sp10da54 = $sp3125db['key']; $sp2b3607 = $this->url_notify; $sp0fb41b = sprintf("version=1.0&mch_id={$sp30b796}&pay_type={$sp690165}&total_amount={$spb7b113}&out_trade_no={$spce6180}&notify_url={$sp2b3607}&key={$sp10da54}"); $sp10cd1f = md5($sp0fb41b); die('
<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>正在转到付款页</title>
</head>
<body onload="document.pay.submit()">
<form name="pay" action="https://pay.jinfupass.com/gateway/h5pay" method="post">
    <input type="hidden" name="version" value="1.0">
    <input type="hidden" name="mch_id" value="' . $sp30b796 . '">
    <input type="hidden" name="pay_type" value="' . $sp690165 . '">
    <input type="hidden" name="fee_type" value="CNY">
    <input type="hidden" name="total_amount" value="' . $spb7b113 . '">
    <input type="hidden" name="device_info" value="AND_WAP">
    <input type="hidden" name="out_trade_no" value="' . $spce6180 . '">
    <input type="hidden" name="notify_url" value="' . $this->url_notify . '">
    <input type="hidden" name="return_url" value="' . $this->url_return . '">
    <input type="hidden" name="body" value="' . $sp73abe8 . '">
    <input type="hidden" name="sp_client_ip" value="' . Helper::getIP() . '">
    <input type="hidden" name="sign" value="' . $sp10cd1f . '">
</form>
</body>
        '); } private function api_wap($sp3125db, $sp690165, $spce6180, $sp73abe8, $spe456af, $spb7b113) { $sp30b796 = $sp3125db['mch_id']; $sp10da54 = $sp3125db['key']; $sp2b3607 = $this->url_notify; $sp0fb41b = sprintf("version=1.0&mch_id={$sp30b796}&pay_type={$sp690165}&total_amount={$spb7b113}&out_trade_no={$spce6180}&notify_url={$sp2b3607}&key={$sp10da54}"); $sp10cd1f = md5($sp0fb41b); $sp7e249e = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . "://{$_SERVER['HTTP_HOST']}"; die('
<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>正在转到付款页</title>
</head>
<body onload="document.pay.submit()">
<form name="pay" action="https://pay.jinfupass.com/gateway/wappay" method="post">
    <input type="hidden" name="version" value="1.0">
    <input type="hidden" name="mch_id" value="' . $sp30b796 . '">
    <input type="hidden" name="pay_type" value="' . $sp690165 . '">
    <input type="hidden" name="fee_type" value="CNY">
    <input type="hidden" name="total_amount" value="' . $spb7b113 . '">
    <input type="hidden" name="device_info" value="AND_WAP">
    <input type="hidden" name="mch_app_name" value="' . SYS_NAME . '">
    <input type="hidden" name="mch_app_id" value="' . $sp7e249e . '">
    <input type="hidden" name="out_trade_no" value="' . $spce6180 . '">
    <input type="hidden" name="notify_url" value="' . $this->url_notify . '">
    <input type="hidden" name="return_url" value="' . $this->url_return . '">
    <input type="hidden" name="body" value="' . $sp73abe8 . '">
    <input type="hidden" name="sp_client_ip" value="' . Helper::getIP() . '">
    <input type="hidden" name="sign" value="' . $sp10cd1f . '">
</form>
</body>
        '); } function refund($sp3125db, $spebe6f4, $spd5193b, $spb7b113) { return '此支付渠道不支持发起退款, 请手动操作'; } }