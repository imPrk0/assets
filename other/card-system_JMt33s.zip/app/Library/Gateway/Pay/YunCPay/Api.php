<?php
namespace Gateway\Pay\YunCPay; use App\Library\CurlRequest; use Gateway\Pay\ApiInterface; use Illuminate\Support\Facades\Log; class Api implements ApiInterface { private $url_notify = ''; private $url_return = ''; public function __construct($spbf68a1) { $this->url_notify = SYS_URL_API . '/pay/notify/' . $spbf68a1; $this->url_return = SYS_URL . '/pay/return/' . $spbf68a1; } function goPay($sp3125db, $spce6180, $sp73abe8, $spe456af, $spb7b113) { $sp32f18a = sprintf('%.2f', $spb7b113 / 100); if (!isset($sp3125db['id'])) { throw new \Exception('请设置id'); } if (!isset($sp3125db['key'])) { throw new \Exception('请设置key'); } $sp66a4b9 = '1.0'; $spdbaca2 = $sp3125db['id']; $sp1a672e = $spce6180; $spe61ecb = $sp3125db['payway']; $sp4434b9 = ''; if (substr($spe61ecb, 0, 4) === 'bank') { $sp4434b9 = substr($spe61ecb, 5); $spe61ecb = 'bank'; } $sp84159d = ''; $sp5405a2 = @intval($sp3125db['is_qrcode']); $sp10cd1f = md5('version=' . $sp66a4b9 . '&customerid=' . $spdbaca2 . '&total_fee=' . $sp32f18a . '&sdorderno=' . $sp1a672e . '&notifyurl=' . $this->url_notify . '&returnurl=' . $this->url_return . '&' . $sp3125db['key']); if (!$sp5405a2) { ?>
            <!doctype html>
            <html>
            <head>
                <meta charset="utf-8">
                <title>正在转到付款页</title>
            </head>
            <body onload="document.pay.submit()">
            <form name="pay" action="http://api.yuncpay.com/api/submit" method="get">
                <input type="hidden" name="version" value="<?php  echo $sp66a4b9; ?>
">
                <input type="hidden" name="customerid" value="<?php  echo $spdbaca2; ?>
">
                <input type="hidden" name="sdorderno" value="<?php  echo $sp1a672e; ?>
">
                <input type="hidden" name="total_fee" value="<?php  echo $sp32f18a; ?>
">
                <input type="hidden" name="paytype" value="<?php  echo $spe61ecb; ?>
">
                <input type="hidden" name="notifyurl" value="<?php  echo $this->url_notify; ?>
">
                <input type="hidden" name="returnurl" value="<?php  echo $this->url_return; ?>
">
                <input type="hidden" name="remark" value="<?php  echo $sp84159d; ?>
">
                <input type="hidden" name="bankcode" value="<?php  echo $sp4434b9; ?>
">
                <input type="hidden" name="is_qrcode" value="0">
                <input type="hidden" name="sign" value="<?php  echo $sp10cd1f; ?>
">
            </form>
            </body>
            </html>

            <?php  } else { $sp4a1cdc = 'version=' . $sp66a4b9 . '&customerid=' . $spdbaca2 . '&sdorderno=' . $sp1a672e . '&total_fee=' . $sp32f18a . '&paytype=' . $spe61ecb . '&notifyurl=' . urlencode($this->url_notify) . '&returnurl=' . urlencode($this->url_return) . '&remark' . urlencode($sp84159d) . '&bankcode=' . $sp4434b9 . '&is_qrcode=1' . '&sign=' . $sp10cd1f; $spfc27c0 = CurlRequest::post('http://api.yuncpay.com/api/submit', $sp4a1cdc); $spa51230 = json_decode($spfc27c0, true); if (!isset($spa51230['status']) || $spa51230['status'] !== 1 || empty($spa51230['code_url'])) { Log::error('Pay.YunCPay.order Error: ' . $spfc27c0); throw new \Exception('获取付款信息超时, 请刷新重试'); } if ($spe61ecb === 'alipay' || $spe61ecb === 'aliwap' || $spe61ecb === 'aliscan') { header('location: /qrcode/pay/' . $spce6180 . '/aliqr?url=' . urlencode($spa51230['code_url'])); } elseif ($spe61ecb === 'wxscan' || $spe61ecb === 'wxwap' || $spe61ecb === 'wxgzh') { header('location: /qrcode/pay/' . $spce6180 . '/wechat?url=' . urlencode($spa51230['code_url'])); } elseif ($spe61ecb === 'qqscan' || $spe61ecb === 'qqwap') { header('location: /qrcode/pay/' . $spce6180 . '/qq?url=' . urlencode($spa51230['code_url'])); } else { throw new \Exception('该支付方式不支持扫码'); } } die; } function verify($sp3125db, $sp5aca2e) { $spd8c93f = isset($sp3125db['isNotify']) && $sp3125db['isNotify']; if ($spd8c93f) { $spfe6f53 = $_POST['status']; $spdbaca2 = $_POST['customerid']; $sp1a672e = $_POST['sdorderno']; $sp32f18a = $_POST['total_fee']; $spe61ecb = $_POST['paytype']; $sp63aace = $_POST['sdpayno']; $sp10cd1f = $_POST['sign']; $sp82bc49 = md5('customerid=' . $spdbaca2 . '&status=' . $spfe6f53 . '&sdpayno=' . $sp63aace . '&sdorderno=' . $sp1a672e . '&total_fee=' . $sp32f18a . '&paytype=' . $spe61ecb . '&' . $sp3125db['key']); if ($sp10cd1f == $sp82bc49) { if ($spfe6f53 == '1') { $sp32f18a = (int) round($sp32f18a * 100); $sp5aca2e($sp1a672e, $sp32f18a, $sp63aace); echo 'success'; return true; } else { echo 'success'; } } else { echo 'sign_err'; } } else { if (!empty($sp3125db['out_trade_no']) || !isset($_GET['sign']) && isset($_GET['sdorderno'])) { $sp1a672e = ''; if (!empty($sp3125db['out_trade_no'])) { $sp1a672e = $sp3125db['out_trade_no']; } elseif (isset($_GET['sdorderno'])) { $sp1a672e = $_GET['sdorderno']; } $sp4a1cdc = 'customerid=' . $sp3125db['id'] . '&sdorderno=' . $sp1a672e . '&reqtime=' . date('YmdHis'); $sp4a1cdc .= '&sign=' . md5($sp4a1cdc . '&' . $sp3125db['key']); $spfc27c0 = CurlRequest::post('http://api.yuncpay.com/api/query', $sp4a1cdc); $spa51230 = json_decode($spfc27c0, true); if (!isset($spa51230['status'])) { Log::error('Pay.YunCPay.verify Error: ' . $spfc27c0); } if ($spa51230['status'] === 1) { $sp32f18a = (int) round($spa51230['total_fee'] * 100); $sp5aca2e($spa51230['sdorderno'], $sp32f18a, $spa51230['sdpayno']); return true; } return false; } $spfe6f53 = $_GET['status']; $spdbaca2 = $_GET['customerid']; $sp1a672e = $_GET['sdorderno']; $sp32f18a = $_GET['total_fee']; $spe61ecb = $_GET['paytype']; $sp63aace = $_GET['sdpayno']; $sp10cd1f = $_GET['sign']; $sp82bc49 = md5('customerid=' . $spdbaca2 . '&status=' . $spfe6f53 . '&sdpayno=' . $sp63aace . '&sdorderno=' . $sp1a672e . '&total_fee=' . $sp32f18a . '&paytype=' . $spe61ecb . '&' . $sp3125db['key']); if ($sp10cd1f == $sp82bc49) { if ($spfe6f53 == '1') { $sp32f18a = (int) round($sp32f18a * 100); $sp5aca2e($sp1a672e, $sp32f18a, $sp63aace); return true; } else { throw new \Exception('付款失败'); } } else { throw new \Exception('sign error'); } } return false; } function refund($sp3125db, $spebe6f4, $spd5193b, $spb7b113) { return '此支付渠道不支持发起退款, 请手动操作'; } }